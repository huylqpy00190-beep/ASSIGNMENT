package com.abcnews.utils;

import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.List;
import java.util.Properties;

public class EmailUtils {
    // Configure SMTP in application - example uses Gmail SMTP (less secure app or app-password required)
    public static void sendBulk(List<String> recipients, String subject, String htmlContent, String smtpHost, String smtpUser, String smtpPass, int smtpPort, boolean useTls) throws Exception {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", String.valueOf(useTls));
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", String.valueOf(smtpPort));

        Session session = Session.getInstance(props, new jakarta.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(smtpUser, smtpPass);
            }
        });
        for (String to : recipients) {
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(smtpUser));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));
            msg.setSubject(subject);
            msg.setContent(htmlContent, "text/html; charset=UTF-8");
            Transport.send(msg);
        }
    }
}
